@extends('layouts.app')

@section('content')
<h1>{{$uprof->briefdescription}}</h1>
@stop