@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading">Scoreboard</div>

				<div class="panel-body">

					
						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-4 col-form-label">Signed Up Users</label>
							<div class="col-xs-7">
								{{$sb}}
							</div>
						</div>

						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-4 col-form-label">Users from Countries</label>
							<div class="col-xs-7">
								@foreach ($arr as $ar)
									@if ($ar->country == "")
										unknown -----> {{$ar->peoplecount}}
									@else
    									{{$ar->country}} -----> {{$ar->peoplecount}} 
    								@endif
    								<br>
								@endforeach
							</div>
						</div>

				</div>
			</div>
		</div>
	</div>
</div>

@stop