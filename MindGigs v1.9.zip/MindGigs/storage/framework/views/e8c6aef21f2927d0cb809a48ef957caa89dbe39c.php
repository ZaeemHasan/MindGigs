<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading">Post</div>

				<div class="panel-body">

					<form method="POST" action="/dashboard" id="fp">
						<?php echo csrf_field(); ?>



						<div class="form-group row">
							<div class="col-xs-10">
								<textarea class="col-xs-offset-1 form-control" name="post" rows="5" type="text" id="post"></textarea>
							</div>
						</div>

						<div class="form-group row">
								<button type="submit" class="col-xs-offset-1 btn btn-primary">Post</button>
						</div>


					</form>

					<div id="successMessage"></div>

				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->startSection('scripts'); ?>
<!--
			<script type="text/javascript">
$("#fp").submit(function( event ) {    
	event.preventDefault();
	var $form = $( this ),
	data = $form.serialize(),
	url = $form.attr( "action" );
	
	var successContent = '<div class="message">'+ data +'</div>';
			$('#successMessage').html(successContent);
	

	var posting = $.post( url, { formData: data } );
	posting.done(function( data ) {
		if(data.fail) {
			$.each(data.errors, function( index, value ) {
				var errorDiv = '#'+index+'_error';
				$(errorDiv).addClass('required');
				$(errorDiv).empty().append(value);
			});
			var successContent = '<div class="message">Failed</div>';
			$('#successMessage').html(successContent);
	//		$('#successMessage').empty();          
		} 
		if(data.success) {
	//		$('.register').fadeOut(); //hiding Reg form
			var successContent = '<div class="message"><h3>Message posted successfully</h3><div class="postDetails"><p><span>Post:</span>'+data.post+'</p></div></div>';
			$('#successMessage').html(successContent);
	    } //success
	}); //done



});
			</script>
		-->
<?php $__env->stopSection(); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>