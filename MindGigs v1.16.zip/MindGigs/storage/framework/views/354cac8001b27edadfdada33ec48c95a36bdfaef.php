<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Edit Profile</div>

				<div class="panel-body">

					<form method="POST" action="../<?php echo e($uprof->username); ?>" id="f2">
						<?php echo csrf_field(); ?>



						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-2 col-form-label">Professional Headline</label>
							<div class="col-xs-7">
								<input required class="form-control" name="proftitle" type="text" value="<?php echo e($uprof->briefdescription); ?>" id="proftitle">
							</div>
						</div>

						<div class="form-group row">
							<label for="address" class="col-xs-offset-1 col-xs-2 col-form-label">Address</label>
							<div class="col-xs-7">
								<input required class="form-control" name="address" type="text" value="<?php echo e($uprof->address); ?>" id="address">
							</div>
						</div>

						<div class="form-group row">
							<label for="city" class="col-xs-offset-1 col-xs-2 col-form-label">City</label>
							<div class="col-xs-7">
								<input required class="form-control" name="city" type="text" value="<?php echo e($uprof->city); ?>" id="city">
							</div>
						</div>

						<div class="form-group row">
							<label for="country" class="col-xs-offset-1 col-xs-2 col-form-label">Country</label>
							<div class="col-xs-7">
								<input required class="form-control" name="country" type="text" value="<?php echo e($uprof->country); ?>" id="country">
							</div>
						</div>

						<div class="form-group row">
							<label for="email" class="col-xs-offset-1 col-xs-2 col-form-label">Email</label>
							<div class="col-xs-7">
								<input class="form-control" name="email" type="text" value="<?php echo e($user->email); ?>" id="email">
							</div>
						</div>

						<div class="form-group row">
							<label for="website" class="col-xs-offset-1 col-xs-2 col-form-label">Website</label>
							<div class="col-xs-7">
								<input class="form-control" name="website" type="url" value="<?php echo e($uprof->website); ?>" id="website">
							</div>
						</div>

						<div class="form-group row">
							<label for="gitlink" class="col-xs-offset-1 col-xs-2 col-form-label">Git-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="gitlink" type="url" value="<?php echo e($uprof->gitlink); ?>" id="gitlink">
							</div>
						</div>

						<div class="form-group row">
							<label for="fblink" class="col-xs-offset-1 col-xs-2 col-form-label">Facebook-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="fblink" type="url" value="<?php echo e($uprof->fblink); ?>" id="fblink">
							</div>
						</div>

						<div class="form-group row">
							<label for="twitlink" class="col-xs-offset-1 col-xs-2 col-form-label">Twitter-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="twitlink" type="url" value="<?php echo e($uprof->twitlink); ?>" id="twitlink">
							</div>
						</div>

						<div class="form-group row">
							<label for="lilink" class="col-xs-offset-1 col-xs-2 col-form-label">LinkedIn-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="lilink" type="url" value="<?php echo e($uprof->lilink); ?>" id="lilink">
							</div>
						</div>

						<div class="form-group row">
							<label for="langs" class="col-xs-offset-1 col-xs-2 col-form-label">Language</label>
							<div class="col-xs-7">
								<input class="form-control" name="langs" type="text" value="<?php echo e($uprof->languages); ?>" id="langs">
							</div>
						</div>


						<div class="form-group row">
							<label for="about" class="col-xs-offset-1 col-xs-2 col-form-label">About</label>
							<div class="col-xs-7">
								<textarea required class="form-control" name="about" rows="5" type="text" id="about"><?php echo e($uprof->about); ?></textarea>
							</div>
						</div>

						<div class="form-group row">
							<label for="interests" class="col-xs-offset-1 col-xs-2 col-form-label">Interests</label>
							<div class="col-xs-7">
								<textarea required class="form-control" name="interests" rows="5" type="text" id="interests"><?php echo e($uprof->interests); ?></textarea>
							</div>
						</div>

						<div class="form-group row">
							<label for="keywords" class="col-xs-offset-1 col-xs-2 col-form-label">Keywords</label>
							<div class="col-xs-7">
								<textarea required class="form-control" name="keywords" rows="5" type="text" id="keywords"><?php echo e($uprof->keywords); ?></textarea>
							</div>
						</div>

						<div class="form-group row">
								<button type="submit" class="col-xs-offset-8 btn btn-primary">Save</button> 
								<button type="button" class="btn btn-primary" onclick="window.location.href='../<?php echo e($uprof->username); ?>'">Cancel</button>
						</div>


					</form>

				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>