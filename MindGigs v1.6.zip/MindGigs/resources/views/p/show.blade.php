@extends('layouts.app')

@section('content')
<br><br>
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">{{$uprof->username}}</div>
				<div class="panel-body">
					<?php 
					if(Auth::check()){
						$authuser = Auth::user()->name;
						if ($authuser == $uprof->username){
					?>
						<h3>	<a href="<?php echo "/".$uprof->username."/editprofile"; ?>">Edit Your Profile</a></h3>
					<?php
						}	
					}
					?>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
@stop