<?php $__env->startSection('style'); ?>
@parent
<link rel="stylesheet" href="<?php echo asset('css/faq.css')?>" type="text/css"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<br><br>
		<h1>Job Posted By: <a href="/<?php echo e($post->author); ?>"><?php echo e($post->author); ?></a></h1>
		<div class="col-md-6 col-md-offset-3">
			
			<div class="panel panel-default"> 
				<div class="panel-heading">Title: <a href="/dashboard/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>; by <a href="/<?php echo e($post->author); ?>"><?php echo e($post->author); ?></a> 
					; at amount $<?php echo e($post->amount); ?> 
					<?php if($post->payment_type == "full time"): ?>
						(full time basis)
					<?php elseif($post->payment_type == "hourly"): ?>
						/ hour basis
					<?php endif; ?>	
				</div>
				<div class="panel-body">
					Keywords: 	&nbsp 	<?php echo e($post->tags); ?><br>
					Start Date: &nbsp	<?php echo e($post->startdate); ?><br>
					Deadline: 	&nbsp 	<?php echo e($post->deadline); ?><br>
					Description:&nbsp	<?php echo e($post->description); ?>

				</div>
			
				<?php if((Auth::check()== true) && (Auth::user()->name == $post->author)): ?>
				<div>
				<form method="POST" action="/dashboard/<?php echo e($post->id); ?>" id="fb">
					<?php echo e(method_field('DELETE')); ?>

    				<?php echo e(csrf_field()); ?>

					<button type="button" class="btn btn-primary" onclick="window.location.href='/dashboard/<?php echo e($post->id); ?>/editpost'">Edit</button>					
					<button type="submit" class="btn btn-primary" >Delete</button>
				</form>
				</div>
				<?php elseif((Auth::check()== true) && (Auth::user()->name != $post->author)): ?>
					<div id="notifier<?php echo e($post->id); ?>" style="background-color:green;color:white;display:none;">Your bid has successfully been placed!</div>
					<div class="toggle">
						<div class="toggle-title">
							<button type="button" class="btn btn-primary title-name togglecloser" id="pressbid<?php echo e($post->id); ?>" onclick="openbidtoggle(<?php echo e($post->id); ?>)">Bid</button>
						</div>


						<div class="toggle-inner">
							
							<div class="form-group row">
								<label for="biddesc" class="col-xs-offset-1 col-xs-3 col-form-label">Why should we hire you?</label>
								<div class="col-xs-7">
									<textarea required class="form-control" name="biddesc<?php echo e($post->id); ?>" placeholder="Why should we hire you?" rows="3" type="text" id="biddesc<?php echo e($post->id); ?>"></textarea>
								</div>
							</div>

							<div class="form-group row">
								<label for="amount" class="col-xs-offset-1 col-xs-3 col-form-label">Amount</label>
								<div class="col-xs-7">
									<input required class="form-control" name="amount<?php echo e($post->id); ?>" type="number" min="1" id="amount<?php echo e($post->id); ?>">
								</div>
							</div>

							<div class="form-group row col-xs-offset-4">
								<button type="button" class="btn btn-primary title-name" id="submitbid<?php echo e($post->id); ?>" onclick="placebid(<?php echo e($post->id); ?>)">Submit Bid</button>
								<button type="button" class="btn btn-primary title-name" id="cancelbid<?php echo e($post->id); ?>" onclick="closebidtoggle(<?php echo e($post->id); ?>)">Cancel Bid</button>
							</div>
						</div>
					</div>
					<div id="testdiv"></div>

				<?php endif; ?>

			</div>

			<?php if((Auth::check()== true) && (Auth::user()->name == $post->author)): ?>
			<br><br><h2>Bids:</h2>
				<?php if(count($bids)>0): ?>
				<br><br>
				<div class="panel panel-default"> 
					
					<?php foreach($bids as $bid): ?>
					
					<div class="panel-heading">Bided amount: <?php echo e($bid->amount); ?>; by <a href="/<?php echo e($bid->username); ?>"><?php echo e($bid->username); ?></a></div>
					<div class="panel-body">
						Why me:<br> &nbsp
						<?php echo e($bid->description); ?>

					</div>
					<?php if($post->status == "waiting"): ?>
						<div id="notifier<?php echo e($bid->id); ?>" style="background-color:green;color:white;display:none;">This bid has successfully been accepted... you can no longer change your option!</div>
						<div class="toggle statchange">
							<div class="toggle-title">
								<button type="button" class="btn btn-primary title-name togglecloser" id="acceptbidbtn<?php echo e($bid->id); ?>" onclick="opentoggle(<?php echo e($bid->id); ?>)">Accept Bid</button>
							</div>
							<div class="toggle-inner">
								
								<div class="form-group row">
									Are you sure you want to accept this bid? (Once accepted, your decision cant be changed)
								</div>

								<div class="form-group row col-xs-offset-4">
									<button type="button" class="btn btn-primary title-name" id="yestobid<?php echo e($bid->id); ?>" onclick="acceptbid(<?php echo e($post->id); ?>,<?php echo e($bid->id); ?>)">Yes</button>
									<button type="button" class="btn btn-primary title-name" id="notobid<?php echo e($bid->id); ?>" onclick="closetoggle(<?php echo e($bid->id); ?>)">No</button>
								</div>
							</div>
						</div>
					<?php elseif($bid->acceptstatus == 1): ?>
						<div id="notifier<?php echo e($bid->id); ?>" style="background-color:green;color:white;">This bid has successfully been accepted... you can no longer change your option!</div>
					<?php endif; ?>
					
					<?php endforeach; ?>

				</div>
				<?php else: ?>
					<h3>No one have placed their bid yet!</h3>
				<?php endif; ?>

			<?php endif; ?>

		</div>

		
	</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

	/*Place Bid JS Starts*/

	function openbidtoggle(id){
		$("#pressbid"+id).addClass("active").closest('.toggle').find('.toggle-inner').slideDown(200);	
	}

	function closebidtoggle(id){
		$("#biddesc"+id).val("");
		$("#amount"+id).val("");
		$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
	}

	function placebid(id){
		$.ajax({
			type: "POST",
			url: "/jobpost",
			data: {postid: id, description: $("#biddesc"+id).val(), amount: $("#amount"+id).val(),  _token: "<?php echo e(Session::token()); ?>"},
			success: function(result){
	   						$("#biddesc"+id).val("");
							$("#amount"+id).val("");
							$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
							$("#notifier"+id).show().delay( 5000 ).hide(0);
	        }
		});
		
	}

	/*Place Bid JS Ends*/
	/*Accept Bid JS Starts*/

	function opentoggle(id){
		$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
		$("#acceptbidbtn"+id).addClass("active").closest('.toggle').find('.toggle-inner').slideDown(200);	
	}

	function closetoggle(id){
		$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
	}

	function acceptbid(pid,bid){
		$.ajax({
			type: "POST",
			url: "/jobbid",
			data: {postid: pid, bidid: bid, _token: "<?php echo e(Session::token()); ?>"},
			success: function(result){
							$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
							$("div").remove(".statchange");
							$("#notifier"+bid).show();
	        }
		});
	}

	/*Accept Bid JS Ends*/

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>