<?php

namespace App\Http\Controllers;

use File;
use Auth;
use App\User;
use App\Profile;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Support\Facades\Input as Input;
use Cookie;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use Illuminate\Cookie\CookieJar;



class ProfilesController extends Controller
{
   protected function validator(array $data)
    {
        return Validator::make($data, [
            'username' => 'required','briefdescription' => 'required','address' => 'required','languages' => 'required','about' => 'required','interests' => 'required',  
        ]);
    }

    protected function create($id, Request $request)
    {
		 $this->validate($request,[
            'address' => 'required',
            'city' => 'required',
            'country' => 'required',
            ]);

        $frame_str="http://localhost:8000/auth/empty";
		$input = Input::all();
		
		$authuser = Auth::user()->name;
		
		$logprof = Profile::where('username',$authuser)->first(); 
		$logprof->briefdescription = $request['proftitle'];
		$logprof->address = $request['address'];
        $logprof->city = $request['city'];
        $logprof->country = $request['country'];
        $logprof->postcode = $request['postcode'];
        $logprof->lati = $request['lat'];
        $logprof->long = $request['lon'];
		$logprof->languages = $request['langs'];
		$logprof->about = $request['about'];
		$logprof->interests = $request['interests'];
        $logprof->keywords = $request['keywords'];
        $logprof->gitlink = $request['gitlink'];
        $logprof->fblink = $request['fblink'];
        $logprof->twitlink = $request['twitlink'];
        $logprof->lilink = $request['lilink'];

		$logprof->save();

        $logusr = User::where('name',$authuser)->first(); 
        $logusr->email = $request['email'];
        $logusr->save();


		return Redirect::to('/'.$authuser);	
    }

    protected function show($id,Request $request){
    	$uvar = User::where('name',$id)->first();
    	$uprof = Profile::where('username',$uvar->name)->first();
    	if (($uprof != null) && (!Auth::check())){
            $cookieval =  $request->cookie('affiliate');
            if ($cookieval == null) {
                    $response = Response(view('p.show',compact('uvar','uprof')));
                    $response->withCookie(Cookie::forever('affiliate', $id));
                    return $response;
            }
            else{   // for updating the cookie... to store new profile's username
                $response = Response(view('p.show',compact('uvar','uprof')));
                $response->withCookie(Cookie::forever('affiliate', $id));
                return $response;
            }
        }
        return view('p.show',compact('uvar','uprof'));
    }

    protected function showep($id){
    	$authuser = Auth::user()->name;
    	if($authuser == $id){
    		$uvar = User::where('name',$id)->first();
    		$uprof = Profile::where('username',$uvar->name)->first();
            $user = User::where('name',$uvar->name)->first();
    		return view('p.showep',compact('uprof','user'));
    	}
    	else {
    		return 'Sorry mate... edit your own profile!';
    	}
    }

    protected function info(){
        $sb = User::count();
        $arr = Profile::selectRaw('country, count(country) as peoplecount')->groupBy('country')->orderBy('country', 'asc')->get();
        
        return view('score',compact('sb','arr'));
    }

}