<?php

namespace App;

use App\User;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = 'posts';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'postauthor', 'post',   
    ];

    public function comments() {
        return $this->hasMany('Comment');
    }

    public function profiles() {
        return $this->belongsTo('Profile');
    }

}