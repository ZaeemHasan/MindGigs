@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row">
		<br><br>
		<center><h1> All Blogs</h1></center>
		<br><br>
		@if(Auth::check()== true)
		<a href="/blogs/create"><h3>Write A New Blog</h3></a>
		@endif
		<div class="col-md-6 col-md-offset-3">
			
			@foreach($blogs as $blog)
			<div class="panel panel-default"> 
				<div class="panel-heading">"<a href="/blogs/{{$blog->id}}">{{$blog->title}}</a>" by <a href="/{{$blog->author}}">{{$blog->author}}</a></div>
				<div class="panel-body">
					{{$blog->body}}
				</div>

				@if((Auth::check()== true) && (Auth::user()->name == $blog->author))
				<div>
				<form method="POST" action="/blogs/{{$blog->id}}" id="fb">
					{{ method_field('DELETE') }}
    				{{ csrf_field() }}
					<button type="button" class="btn btn-primary" onclick="window.location.href='/blogs/{{$blog->id}}/editblog'">Edit</button>					
					<button type="submit" class="btn btn-primary" >Delete</button>
				</form>
				</div>
				@endif

			</div>
			@endforeach
		
		</div>
	</div>
</div>

@stop