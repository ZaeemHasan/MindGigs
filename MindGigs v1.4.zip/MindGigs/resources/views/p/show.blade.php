@extends('layouts.app')

@section('content')
<h1>Username: {{$uprof->username}}</h1>
<h2>Brief Description: {{$uprof->briefdescription}}</h2><br><br>
<?php 
	$authuser = Auth::user()->name;
	if ($authuser == $uprof->username){
?>
	<h3>	<a href="<?php echo "/".$uprof->username."/editprofile"; ?>">Edit Your Profile</a></h3>
<?php
}
?>
@stop