<?php $__env->startSection('style'); ?>
@parent
<link rel="stylesheet" href="<?php echo asset('css/faq.css')?>" type="text/css"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">

			<center><h1>The Posts On Which I've Bidded</h1></center><br>
			
			<?php foreach($posts as $post): ?>
			<div class="panel panel-default"> 
				<div class="panel-heading">Title: <a href="/dashboard/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>; by <a href="/<?php echo e($post->author); ?>"><?php echo e($post->author); ?></a> 
					; at amount $<?php echo e($post->amount); ?> 
					<?php if($post->payment_type == "full time"): ?>
						(full time basis)
					<?php elseif($post->payment_type == "hourly"): ?>
						/ hour basis
					<?php endif; ?>	

				</div>
				<div class="panel-body">
					Keywords: 	&nbsp 	<?php echo e($post->tags); ?><br>
					Start Date: &nbsp 	<?php echo e($post->startdate); ?><br>
					Deadline: 	&nbsp 	<?php echo e($post->deadline); ?><br>
					Description:&nbsp	<?php echo e($post->description); ?>

				</div>
			</div>
			<?php endforeach; ?>
		
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>