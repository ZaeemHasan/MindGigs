<?php

namespace App;

use App\User;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table = 'comments';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'post_id','commentauthor', 'comment',   
    ];

    public function posts() {
        return $this->belongsTo('Post');
    }

    public function profiles() {
        return $this->belongsTo('Profile');
    }

}