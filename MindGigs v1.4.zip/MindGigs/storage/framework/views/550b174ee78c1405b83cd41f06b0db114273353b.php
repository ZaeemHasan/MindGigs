<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Edit Profile</div>

                <div class="panel-body">
                    
                	<form method="POST" action="../<?php echo e($uprof->username); ?>" id="f2">
						<?php echo csrf_field(); ?>

						Profile Title &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="proftitle" required rows="1" form="f2" cols="100" placeholder="Enter profile title here"><?php echo e($uprof->briefdescription); ?></textarea><br><br>
						Address &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="address" required rows="1" form="f2" cols="100" placeholder="Enter address here"><?php echo e($uprof->address); ?></textarea><br><br>
						Git-link<br>
						<textarea name="gitlink" rows="1" form="f2" cols="100" placeholder="Enter git-link here"><?php echo e($uprof->gitlink); ?></textarea><br><br>
						FB-link<br>
						<textarea name="fblink" rows="1" form="f2" cols="100" placeholder="Enter fb-link here"><?php echo e($uprof->fblink); ?></textarea><br><br>
						Twitter-link<br>
						<textarea name="twlink" rows="1" form="f2" cols="100" placeholder="Enter twitter-link here"><?php echo e($uprof->twitlink); ?></textarea><br><br>
						LinkedIn-link<br>
						<textarea name="lilink" rows="1" form="f2" cols="100" placeholder="Enter linkedin-link here"><?php echo e($uprof->lilink); ?></textarea><br><br>
						Languages &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="langs" required rows="1" form="f2" cols="100" placeholder="Enter languages here"><?php echo e($uprof->languages); ?></textarea><br><br>
						About &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="about" required rows="10" form="f2" cols="100" placeholder="Enter your about information here"><?php echo e($uprof->about); ?></textarea><br><br>
						Interests &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="interests" required rows="5" form="f2" cols="100" placeholder="Enter interests here"><?php echo e($uprof->interests); ?></textarea><br><br>
						
						<button type="submit">Save</button> <button type="button" onclick="window.location.href='../<?php echo e($uprof->username); ?>'">Cancel</button>
					</form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>