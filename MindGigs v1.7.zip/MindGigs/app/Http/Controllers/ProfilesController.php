<?php

namespace App\Http\Controllers;

use File;
use Auth;
use App\User;
use App\Profile;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Support\Facades\Input as Input;
use Cookie;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use Illuminate\Cookie\CookieJar;



class ProfilesController extends Controller
{
   protected function validator(array $data)
    {
        return Validator::make($data, [
            'username' => 'required','briefdescription' => 'required','address' => 'required','languages' => 'required','about' => 'required','interests' => 'required',  
        ]);
    }

    protected function create($id)
    {
		$frame_str="http://localhost:8000/auth/empty";
		$input = Input::all();
			
//		$id = Auth::id();
//		$usr = User::find($id);
//		$logprof = new Profile;

		$authuser = Auth::user()->name;
		
		$logprof = Profile::where('username',$authuser)->first(); 
		$logprof->briefdescription = $input['proftitle'];
		$logprof->address = $input['address'];
		$logprof->languages = $input['langs'];
		$logprof->about = $input['about'];
		$logprof->interests = $input['interests'];
        $logprof->gitlink = $input['gitlink'];
        $logprof->fblink = $input['fblink'];
        $logprof->twitlink = $input['twitlink'];
        $logprof->lilink = $input['lilink'];

		$logprof->save();

		return Redirect::to(''.$authuser);	
    }

    protected function show($id,Request $request){
    	$uvar = User::where('name',$id)->first();
    	$uprof = Profile::where('username',$uvar->name)->first();
    	if (($uprof != null) && (!Auth::check())){
            $cookieval =  $request->cookie('affiliate');
            if ($cookieval == null) {
                    $response = Response(view('p.show',compact('uvar','uprof')));
                    $response->withCookie(Cookie::forever('affiliate', $id));
                    return $response;
            }
            else{   // for updating the cookie... to store new profile's username
                $response = Response(view('p.show',compact('uvar','uprof')));
                $response->withCookie(Cookie::forever('affiliate', $id));
                return $response;
            }
        }
        return view('p.show',compact('uvar','uprof'));
    }

    protected function showep($id){
    	$authuser = Auth::user()->name;
    	if($authuser == $id){
    		$uvar = User::where('name',$id)->first();
    		$uprof = Profile::where('username',$uvar->name)->first();
    		return view('p.showep',compact('uprof'));
    	}
    	else {
    		return 'Sorry mate... edit your own profile!';
    	}
    }

}