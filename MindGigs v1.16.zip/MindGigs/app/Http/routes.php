<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
 */

Route::get('/home', function () {                                  // a simple home page that redirects to user profile (from starting increments)
    if (Auth::check()) {
        return view('home');
    } else {
        return Redirect::to('login');
    }
});

Route::get('searchjobs', 'DashboardController@searchview');        // page for searching jobs/professionals with few filters---- only logged in users can view & use it
Route::get('searchjobsint', 'DashboardController@searchAcInt');    // not using this --- coz we have updated things 
Route::post('searchjobs', 'DashboardController@jobsearch');        // post request for viewing jobs posts according to required skills
Route::post('searchprofs', 'DashboardController@profsearch');      // post request for viewing professionals according to required skills
Route::post('search', 'DashboardController@search');               // post request for viewing jobs for required skills --- any user can use it (i.e. both visiting as well as logged in user)
Route::get('search',function () {                                  
    return Redirect::to('/');
});


Route::get('dashboard', 'DashboardController@index');                // page where all posted jobs are viewable (i.e. to both visiting as well as logged in user)
Route::get('dashboard/create', 'DashboardController@create');        // page for creating a new job post
Route::get('dashboard/{id}', 'DashboardController@show');            // page for viewing particular job post / viewing all bids / accepting bids / viewing logged in user's own bids (different type of views depending on situation)
Route::get('dashboard/{id}/editpost', 'DashboardController@showeb'); // page for editing logged in user's job post
Route::get('{id}/dashboard', 'DashboardController@showpb');          // page for viewing particular profile's all posted job posts
Route::get('{id}/dashboard/biddedposts', 'DashboardController@showbidpost'); // page for viewing logged in user's all job posts on which he/she has bidded

Route::post('dashboard', 'DashboardController@store');               // post request for saving new job post
Route::post('dashboard/{id}', 'DashboardController@edit');           // post request for editing logged in user's job post
Route::delete('dashboard/{id}', 'DashboardController@destroy');      // delete request for deleting logged in user's job post
Route::post('jobpost', 'DashboardController@bidpost');               // post request for bidding on some job post
Route::post('jobbid', 'DashboardController@bidaccept');              // post request for accepting bid of some job post


// made indirect links by making showep.blade.php and show.blade.php to make it more secure

Route::get('/', function () {                                        // root page (main website page)
    return view('welcome');
});

Route::get('/scoreboard', 'ProfilesController@info');                // page for scoreboard which is viewable by all (i.e. both visiting as well as logged in user)
 


Route::get('blogs', 'BlogsController@index');                        // page where all published blogs are viewable (i.e. to both visiting as well as logged in user)  
Route::get('blogs/create', 'BlogsController@create');                // page for creating a new blog
Route::get('blogs/{id}', 'BlogsController@show');                    // page for viewing particular blog (i.e. to both visiting as well as logged in user)
Route::get('blogs/{id}/editblog', 'BlogsController@showeb');         // page for view for editing logged in user's old blog
Route::get('{id}/blogs', 'BlogsController@showpb');                  // page for viewing particular profile's all published blogs

Route::post('blogs', 'BlogsController@store');                       // post request for saving new blog
Route::post('blogs/{id}', 'BlogsController@edit');                   // post request for editing logged in user's some blog
Route::delete('blogs/{id}', 'BlogsController@destroy');              // post request for deleting logged in user's some blog



/*  Note that: localhost:8000/editprofile and localhost:8000/profile are not official pages

Route::get('/profile', function () {   // "model" profile page ... which is obviously for testing and comparing dynamic profile purpose 
    if (Auth::check()) {
        return view('profile');
    } else {
        return Redirect::to('login');
    }
});
Route::get('/editprofile', function () {
    if (Auth::check()) {
        return view('editprofile');
    } else {
        return Redirect::to('login');
    }
});

*/

/*   
    Note that we are using this api for getting location from ipaddress
                https://github.com/Torann/laravel-geoip/ 
*/

Route::auth();

Route::get('{id}', 'ProfilesController@show');                       // "main" profile page
Route::get('{id}/editprofile', 'ProfilesController@showep');         // page for editing profile

Route::post('{id}', 'ProfilesController@create');                    // post request for updating profile data

Route::get('{id}/{slug}', 'BlogsController@showslg');                // page for viewing particular profile's particular blog via slug