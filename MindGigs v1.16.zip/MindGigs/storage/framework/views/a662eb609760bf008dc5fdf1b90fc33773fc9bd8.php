<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<br><br>
		<div class="col-md-6 col-md-offset-3">
			<div id="testdiv">
			<h1>Jobs According To Your Required Keywords</h1><br/><br/><br/>
			<?php foreach($posts as $post): ?>
			<div class="panel panel-default"> 
				<div class="panel-heading">Title: <a href="/dashboard/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>; by <a href="/<?php echo e($post->author); ?>"><?php echo e($post->author); ?></a> 
					; at amount $<?php echo e($post->amount); ?> 
					<?php if($post->payment_type == "full time"): ?>
						(full time basis)
					<?php elseif($post->payment_type == "hourly"): ?>
						/ hour basis
					<?php endif; ?>	
					 &nbsp &nbsp -----> &nbsp &nbsp[<?php echo e($post->dist); ?> km away]
				</div>
				<div class="panel-body">
					Keywords: 	&nbsp 	<?php echo e($post->tags); ?><br>
					Start Date: &nbsp 	<?php echo e($post->startdate); ?><br>
					Deadline: 	&nbsp 	<?php echo e($post->deadline); ?><br>
					Description:&nbsp	<?php echo e($post->description); ?>

				</div>
			</div>
			<?php endforeach; ?>

			</div>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>