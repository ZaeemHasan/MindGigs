@extends('layouts.app')

@section('style')
@parent
<link rel="stylesheet" href="<?php echo asset('css/faq.css')?>" type="text/css"> 
@endsection

@section('content')
<div class="container">
	<div class="row">
		<br><br>
		<h1>Job Posted By: <a href="/{{$post->author}}">{{$post->author}}</a></h1>
		<div class="col-md-6 col-md-offset-3">
			
			<div class="panel panel-default"> 
				<div class="panel-heading">Title: <a href="/dashboard/{{$post->id}}">{{$post->title}}</a>; by <a href="/{{$post->author}}">{{$post->author}}</a> 
					; at amount ${{$post->amount}} 
					@if($post->payment_type == "full time")
						(full time basis)
					@elseif($post->payment_type == "hourly")
						/ hour basis
					@endif	
				</div>
				<div class="panel-body">
					Keywords: 	&nbsp 	{{$post->tags}}<br>
					Start Date: &nbsp	{{$post->startdate}}<br>
					Deadline: 	&nbsp 	{{$post->deadline}}<br>
					Description:&nbsp	{{$post->description}}
				</div>
			
				@if((Auth::check()== true) && (Auth::user()->name == $post->author))
				<div>
				<form method="POST" action="/dashboard/{{$post->id}}" id="fb">
					{{ method_field('DELETE') }}
    				{{ csrf_field() }}
					<button type="button" class="btn btn-primary" onclick="window.location.href='/dashboard/{{$post->id}}/editpost'">Edit</button>					
					<button type="submit" class="btn btn-primary" >Delete</button>
				</form>
				</div>
				@endif

			</div>

			@if((Auth::check()== true) && (Auth::user()->name == $post->author))
			<br><br><h2>Bids:</h2>
				@if(count($bids)>0)
				<br><br>
				<div class="panel panel-default"> 
					
					@foreach($bids as $bid)
					
					<div class="panel-heading">Bided amount: {{$bid->amount}}; by <a href="/{{$bid->username}}">{{$bid->username}}</a></div>
					<div class="panel-body">
						Why me:<br> &nbsp
						{{$bid->description}}
					</div>
					@if($post->status == "waiting")
						<div id="notifier{{$bid->id}}" style="background-color:green;color:white;display:none;">This bid has successfully been accepted... you can no longer change your option!</div>
						<div class="toggle statchange">
							<div class="toggle-title">
								<button type="button" class="btn btn-primary title-name togglecloser" id="acceptbidbtn{{$bid->id}}" onclick="opentoggle({{$bid->id}})">Accept Bid</button>
							</div>
							<div class="toggle-inner">
								
								<div class="form-group row">
									Are you sure you want to accept this bid? (Once accepted, your decision cant be changed)
								</div>

								<div class="form-group row col-xs-offset-4">
									<button type="button" class="btn btn-primary title-name" id="yestobid{{$bid->id}}" onclick="acceptbid({{$post->id}},{{$bid->id}})">Yes</button>
									<button type="button" class="btn btn-primary title-name" id="notobid{{$bid->id}}" onclick="closetoggle({{$bid->id}})">No</button>
								</div>
							</div>
						</div>
					@elseif($bid->acceptstatus == 1)
						<div id="notifier{{$bid->id}}" style="background-color:green;color:white;">This bid has successfully been accepted... you can no longer change your option!</div>
					@endif
					
					@endforeach

				</div>
				@else
					<h3>No one have placed their bid yet!</h3>
				@endif

			@endif

		</div>

		
	</div>
</div>

@stop


@section('scripts')
<script type="text/javascript">

	function opentoggle(id){
		$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
		$("#acceptbidbtn"+id).addClass("active").closest('.toggle').find('.toggle-inner').slideDown(200);	
	}

	function closetoggle(id){
		$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
	}

	function acceptbid(pid,bid){
		$.ajax({
			type: "POST",
			url: "/jobbid",
			data: {postid: pid, bidid: bid, _token: "{{ Session::token() }}"},
			success: function(result){
							$(".togglecloser").removeClass("active").closest('.toggle').find('.toggle-inner').slideUp(200);
							$("div").remove(".statchange");
							$("#notifier"+bid).show();
	        }
		});

	
		
	}

</script>
@endsection