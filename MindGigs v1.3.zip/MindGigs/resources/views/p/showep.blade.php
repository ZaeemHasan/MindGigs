@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Edit Profile</div>

                <div class="panel-body">
                    
                	<form method="POST" action="/p" id="f2">
						{!! csrf_field() !!}
						Profile Title &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="proftitle" required rows="1" form="f2" cols="100" placeholder="Enter profile title here">{{$uprof->briefdescription}}</textarea><br><br>
						Address &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="address" required rows="1" form="f2" cols="100" placeholder="Enter address here">{{$uprof->address}}</textarea><br><br>
						Git-link<br>
						<textarea name="gitlink" rows="1" form="f2" cols="100" placeholder="Enter git-link here">{{$uprof->gitlink}}</textarea><br><br>
						FB-link<br>
						<textarea name="fblink" rows="1" form="f2" cols="100" placeholder="Enter fb-link here">{{$uprof->fblink}}</textarea><br><br>
						Twitter-link<br>
						<textarea name="twlink" rows="1" form="f2" cols="100" placeholder="Enter twitter-link here">{{$uprof->twitlink}}</textarea><br><br>
						LinkedIn-link<br>
						<textarea name="lilink" rows="1" form="f2" cols="100" placeholder="Enter linkedin-link here">{{$uprof->lilink}}</textarea><br><br>
						Languages &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="langs" required rows="1" form="f2" cols="100" placeholder="Enter languages here">{{$uprof->languages}}</textarea><br><br>
						About &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="about" required rows="10" form="f2" cols="100" placeholder="Enter your about information here">{{$uprof->about}}</textarea><br><br>
						Interests &nbsp&nbsp&nbsp&nbsp&nbsp*<br>
						<textarea name="interests" required rows="5" form="f2" cols="100" placeholder="Enter interests here">{{$uprof->interests}}</textarea><br><br>
						
						<button type="submit">Save</button> <button type="button" onclick="window.location.href='../../epredct'">Cancel</button>
					</form>

                </div>
            </div>
        </div>
    </div>
</div>

@stop