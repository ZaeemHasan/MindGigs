<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
	<div class="row">
        <div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">Scoreboard</div>

				<div class="panel-body">

					
						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-4 col-form-label">Signed Up Users</label>
							<div class="col-xs-7">
								<table class="table table-responsive table-hover"> <tr><td><?php echo e($sb); ?></td></tr> </table>
							</div>
						</div>

						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-4 col-form-label">Users from Countries</label>
							<div class="col-xs-7">
								<table class="table table-responsive table-hover">
									<tr>
										<th> Country </th>
										<th> Members </th>
									<tr>
									<?php foreach($arr as $ar): ?>
									<tr>
										<?php if($ar->country == ""): ?>
											<td>unknown</td> <td><?php echo e($ar->peoplecount); ?></td>
										<?php else: ?>
	    									<td><?php echo e($ar->country); ?></td>  <td><?php echo e($ar->peoplecount); ?></td>
	    								<?php endif; ?>
	    							<tr>
									<?php endforeach; ?>
									</tr>
								</table>
							</div>
						</div>

				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>