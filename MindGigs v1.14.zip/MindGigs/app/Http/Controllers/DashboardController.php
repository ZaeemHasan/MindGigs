<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Profile;
use App\Projbid;
use App\Projpost;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input as Input;
use Illuminate\Support\Facades\Redirect;

class DashboardController extends Controller
{

    public function index()
    {
        $posts = Projpost::latest()->get();
        return view('dashboard.index', compact('posts'));
    }

    public function show($id)
    {
        $post = Projpost::findOrFail($id);
        $bids = Projbid::where('projpost_id', $id)->get();

        return view('dashboard.show', compact('post', 'bids'));
    }

    public function showpb($id)
    {
        $posts = Projpost::where('author', $id)->latest()->get();
        return view('dashboard.pindex', compact('posts', 'id'));
    }

    public function create()
    {
        if (Auth::check()) {
            $authuser = Auth::user()->name;
            return view('dashboard.create', compact('authuser'));
        } else {
            return Redirect::to('login');
        }
    }

    public function store()
    {
        $input    = Input::all();
        $authuser = Auth::user()->name;

        $newpost               = new Projpost;
        $newpost->author       = $authuser;
        $newpost->title        = $input['title'];
        $newpost->description  = $input['description'];
        $newpost->tags         = strtoupper($input['tags']);
        $newpost->payment_type = $input['pt'];
        $newpost->startdate    = $input['startdate'];
        $newpost->deadline     = $input['deadline'];
        $newpost->amount       = $input['amount'];
        $newpost->status       = 'waiting';

        $newpost->save();

        return redirect($authuser . '/dashboard');
    }

    public function showeb($id) // show edit blog for particular blog

    {
        $authuser = Auth::user()->name;
        $post     = Projpost::findOrFail($id);
        if ((Auth::check() == true) && ($authuser == $post->author)) {
            if ($post->status == 'waiting') {
                return view('dashboard.edit', compact('post'));
            } else {
                return "Your posted project can not be edited, as it has already been awarded!";
            }
        } else {
            return 'Edit your own job posts';
        }
    }

    public function edit($id)
    {
        $authuser = Auth::user()->name;
        $input    = Input::all();

        $post               = Projpost::findOrFail($id);
        $post->title        = $input['title'];
        $post->description  = $input['description'];
        $post->tags         = strtoupper($input['tags']);
        $post->payment_type = $input['pt'];
        $post->startdate    = $input['startdate'];
        $post->deadline     = $input['deadline'];
        $post->amount       = $input['amount'];
        $post->save();

        return redirect($authuser . '/dashboard');

    }

    public function destroy($id)
    {
        $post = Projpost::findOrFail($id);
        if ($post->status == 'waiting') {
            $post = Projpost::findOrFail($id);
            $post->delete();
            $authuser = Auth::user()->name;
            return redirect($authuser . '/dashboard');
        } else {
            return "Your posted project can not be deleted, as it has already been awarded!";
        }
    }

    public function bidpost(Request $request)
    {
        $this->validate($request, [
            'postid'      => 'required',
            'description' => 'required',
            'amount'      => 'required',
        ]);
        $authuser = Auth::user()->name;

        $placebid               = new Projbid;
        $placebid->projpost_id  = $request['postid'];
        $placebid->username     = $authuser;
        $placebid->description  = $request['description'];
        $placebid->amount       = $request['amount'];
        $placebid->acceptstatus = 0;
        $placebid->save();

        if ($request->ajax()) {
            return response()->json();
        }

    }

    public function bidaccept(Request $request)
    {
        $this->validate($request, [
            'postid' => 'required',
            'bidid'  => 'required',
        ]);

        $pid = $request['postid'];
        $bid = $request['bidid'];

        $post                  = Projpost::findOrFail($pid);
        $post->status          = 'awarded';
        $post->accepted_bid_id = $bid;
        $post->save();

        $bid               = Projbid::findOrFail($bid);
        $bid->acceptstatus = 1;
        $bid->save();

        if ($request->ajax()) {
            return response()->json();
        }

    }

    public function searchview()
    {
        //Request $request --- in case if you need to fetch logged in user ip
        if (Auth::check()) {
            //        $request->setTrustedProxies(array('127.0.0.1'));
            //        $ip = $request->getClientIp();

            // SHIFT FOLLOWING BLOCK WITH GETTING IP BLOCL OF CURRENT USER SO THAT ITS LOCATION CAN BE CALCULATED.. SO THAT USER DONT NEEDS TO LOG IN TO SEARCH JOBS
            /*  Block of Current User To Get it's location for distance starts   */      
            $authuser = Auth::user()->name;
            $usr      = Profile::where('username', $authuser)->first();
            $lat1  = $usr->lati;               
            $lon1  = $usr->long;            
            /*  Block Ends  */

            $searchWords = explode(",", strtolower($usr->keywords));
            
            $posts =  DB::table('projposts')->join('profiles', 'projposts.author', '=', 'profiles.username');
            foreach ($searchWords as $word) {
                $posts->orWhere('tags', 'LIKE', '%' . $word . '%');
            }
            $posts = $posts->distinct()->get();
            $arrays = array();
            foreach ($posts as $post) {
                // src = http://www.geodatasource.com/developers/php
                $lat2  = $post->lati;
                $lon2  = $post->long;
                $theta = $lon1 - $lon2;

                $dist       = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
                $dist       = acos($dist);
                $dist       = rad2deg($dist);
                $km         = $dist * 60 * 1.1515 * 1.609344;
                $post->dist = $km;
                $arrays[] = $post;
            }

            usort($arrays, array($this, "cmp"));

            return view('dashboard.search', compact('posts'));
        } else {
            return Redirect::to('login');
        }
    }

    public function jobsearch(Request $request)
    {
        $this->validate($request, [
            'tosearch' => 'required',
        ]);

        // SHIFT FOLLOWING BLOCK WITH GETTING IP BLOCL OF CURRENT USER SO THAT ITS LOCATION CAN BE CALCULATED.. SO THAT USER DONT NEEDS TO LOG IN TO SEARCH JOBS
        /*  Block of Current User To Get it's location for distance starts   */      
        $authuser = Auth::user()->name;
        $usr      = Profile::where('username', $authuser)->first();
        $lat1  = $usr->lati;               
        $lon1  = $usr->long;            
        /*  Block Ends  */


        $searchWords = explode(",", strtolower($request['tosearch']));

        $posts =  DB::table('projposts')->join('profiles', 'projposts.author', '=', 'profiles.username');
        foreach ($searchWords as $word) {
            $posts->orWhere('tags', 'LIKE', '%' . $word . '%');
        }
        $posts = $posts->distinct()->get();
        $arrays = array();
        foreach ($posts as $post) {
            // src = http://www.geodatasource.com/developers/php
            $lat2  = $post->lati;
            $lon2  = $post->long;
            $theta = $lon1 - $lon2;

            $dist       = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
            $dist       = acos($dist);
            $dist       = rad2deg($dist);
            $km         = $dist * 60 * 1.1515 * 1.609344;
            $post->dist = $km;
            $arrays[] = $post;
        }

        usort($arrays, array($this, "cmp"));
        

        if ($request->ajax()) {
            return response()->json(['success' => true, 'posts' => $posts]);
        }
        return $posts;
    }

    public function profsearch(Request $request) // profs == professionals

    {
        $this->validate($request, [
            'tosearch' => 'required',
        ]);

        // SHIFT FOLLOWING BLOCK WITH GETTING IP BLOCL OF CURRENT USER SO THAT ITS LOCATION CAN BE CALCULATED.. SO THAT USER DONT NEEDS TO LOG IN TO SEARCH JOBS
        /*  Block of Current User To Get it's location for distance starts   */      
        $authuser = Auth::user()->name;
        $usr      = Profile::where('username', $authuser)->first();
        $lat1  = $usr->lati;               
        $lon1  = $usr->long;            
        /*  Block Ends  */

        $searchWords = explode(",", strtolower($request['tosearch']));

        $profs = Profile::query();
        foreach ($searchWords as $word) {
            $profs->orWhere('keywords', 'LIKE', '%' . $word . '%');
        }
        $profs = $profs->distinct()->get();
		$arrays = array();
        foreach ($profs as $prof) {
            // src = http://www.geodatasource.com/developers/php
            $lat2  = $prof->lati;
            $lon2  = $prof->long;
            $theta = $lon1 - $lon2;

            $dist  		= sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
            $dist       = acos($dist);
            $dist       = rad2deg($dist);
            $km         = $dist * 60 * 1.1515 * 1.609344;
            $prof->dist = $km;
            $arrays[] = $prof;
        }

        usort($arrays, array($this, "cmp"));



        if ($request->ajax()) {
            return response()->json(['success' => true, 'profs' => $arrays]);
        }
        return $profs;
    }


	public function cmp($a, $b)
	{
	    if ($a->dist == $b->dist) {
	        return 0;
	    }
	    return ($a->dist < $b->dist) ? -1 : 1;
	}

    public function searchAcInt(Request $request) // search according to interests saved by the user in his/her profile

    {

        $authuser    = Auth::user()->name;
        $usr         = Profile::where('username', $authuser)->first();
        $searchWords = explode(",", strtolower($usr->keywords));

        $posts = Projpost::query();
        foreach ($searchWords as $word) {
            $posts->orWhere('tags', 'LIKE', '%' . $word . '%');
        }
        $posts = $posts->distinct()->get();

        if ($request->ajax()) {
            return response()->json(['success' => true, 'posts' => $posts]);
        }
        //      return response()->json(['success'=>true,'posts'=>$posts]);
        //       return Response::json(['success'=>true,'data'=>$data]);

        return $posts;
    }

}
