<?php

namespace App\Http\Controllers;

use File;
use Auth;
use App\User;
use App\Profile;
use App\Post;
use App\Comment;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Support\Facades\Input as Input;

use App\Http\Requests;

class DashboardController extends Controller
{
    
    protected function store()
    {	
		$input = Input::all();
	   	$authuser = Auth::user()->name;
	   	
		$newPost = new Post;
	   	$newPost->author = $authuser;
	   	$newPost->postauthor = $input['postauthor'];
       	$newPost->post = $input['post'];
	   	$newblog->save();

    	return redirect('/dashboard');

/*		$authuser = Auth::user()->name;

		$inputData = Input::get('formData');
    	parse_str($inputData, $formFields);  
    	$userData = array(
      		'postauthor'=>	$authuser,
      		'post'		=>	$formFields['post'],
      	);
	    $rules = array(
	        'post'      =>  'required|min:1',
	    );
	    $validator = Validator::make($userData,$rules);
	    if($validator->fails())
	        return Response::json(array(
	            'fail' => true,
	            'errors' => $validator->getMessageBag()->toArray()
	        ));
	    else {
	        //$password = $userData['password'];
		    
		    $newPost = new Post;
		    $newPost->postauthor = $userData['postauthor'];
       		$newPost->post = $userData['post'];

			$newPost->save();


		    if(Post::create($userData)) {  
		        //return success  message
		        return Response::json(array(
		    	    'success'	=>	true,
		        	'postauthor'=>	$userData['postauthor'],
		        	'post'		=>	$userData['post']
		        ));
		    }
		}
		*/
    }
}
