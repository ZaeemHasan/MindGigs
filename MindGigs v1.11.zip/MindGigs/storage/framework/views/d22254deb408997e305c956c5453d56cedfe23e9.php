<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<br><br>
		<center><h1> All Blogs</h1></center>
		<br><br>
		<?php if(Auth::check()== true): ?>
		<a href="/blogs/create"><h3>Write A New Blog</h3></a>
		<?php endif; ?>
		<div class="col-md-6 col-md-offset-3">
			
			<?php foreach($blogs as $blog): ?>
			<div class="panel panel-default"> 
				<div class="panel-heading">"<a href="/blogs/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a>" by <a href="/<?php echo e($blog->author); ?>"><?php echo e($blog->author); ?></a></div>
				<div class="panel-body">
					<?php echo e($blog->body); ?>

				</div>

				<?php if((Auth::check()== true) && (Auth::user()->name == $blog->author)): ?>
				<div>
				<form method="POST" action="/blogs/<?php echo e($blog->id); ?>" id="fb">
					<?php echo e(method_field('DELETE')); ?>

    				<?php echo e(csrf_field()); ?>

					<button type="button" class="btn btn-primary" onclick="window.location.href='/blogs/<?php echo e($blog->id); ?>/editblog'">Edit</button>					
					<button type="submit" class="btn btn-primary" >Delete</button>
				</form>
				</div>
				<?php endif; ?>

			</div>
			<?php endforeach; ?>
		
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>