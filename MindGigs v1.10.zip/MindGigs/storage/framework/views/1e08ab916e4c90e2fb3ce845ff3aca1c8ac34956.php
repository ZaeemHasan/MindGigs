<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading">Scoreboard</div>

				<div class="panel-body">

					
						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-4 col-form-label">Signed Up Users</label>
							<div class="col-xs-7">
								<?php echo e($sb); ?>

							</div>
						</div>

						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-4 col-form-label">Users from Countries</label>
							<div class="col-xs-7">
								<?php foreach($arr as $ar): ?>
    								<?php echo e($ar->country); ?> -----> <?php echo e($ar->peoplecount); ?> 
    								<br>
								<?php endforeach; ?>
							</div>
						</div>

				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>