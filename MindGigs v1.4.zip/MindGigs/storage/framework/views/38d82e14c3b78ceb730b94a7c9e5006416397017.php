<?php $__env->startSection('content'); ?>
<h1>Username: <?php echo e($uprof->username); ?></h1>
<h2>Brief Description: <?php echo e($uprof->briefdescription); ?></h2><br><br>
<?php 
	$authuser = Auth::user()->name;
	if ($authuser == $uprof->username){
?>
	<h3>	<a href="<?php echo "/".$uprof->username."/editprofile"; ?>">Edit Your Profile</a></h3>
<?php
}
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>