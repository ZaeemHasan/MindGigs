@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Edit Profile</div>

				<div class="panel-body">

					<form method="POST" id="fep">
						{!! csrf_field() !!}


						<div class="form-group row">
							<label for="proftitle" class="col-xs-offset-1 col-xs-2 col-form-label">Professional Headline</label>
							<div class="col-xs-7">
								<input required class="form-control" name="proftitle" type="text" value="{{$uprof->briefdescription}}" id="proftitle">
							</div>
						</div>

						<div class="form-group row">
							<label for="address" class="col-xs-offset-1 col-xs-2 col-form-label">Address</label>
							<div class="col-xs-7">
								<input required class="form-control" name="address" type="text" value="{{$uprof->address}}" id="address">
							</div>
						</div>

						<div class="form-group row">
							<label for="city" class="col-xs-offset-1 col-xs-2 col-form-label">City</label>
							<div class="col-xs-7">
								<input required class="form-control" name="city" type="text" value="{{$uprof->city}}" id="city">
							</div>
						</div>

						<div class="form-group row">
							<label for="country" class="col-xs-offset-1 col-xs-2 col-form-label">Country</label>
							<div class="col-xs-7">
								<input required class="form-control" name="country" type="text" value="{{$uprof->country}}" id="country">
							</div>
						</div>

						<div class="form-group row">
							<label for="postcode" class="col-xs-offset-1 col-xs-2 col-form-label">Post Code</label>
							<div class="col-xs-7">
								<input required class="form-control" name="postcode" type="text" value="{{$uprof->postcode}}" id="postcode">
							</div>
						</div>

						<div class="form-group row">
							<label for="email" class="col-xs-offset-1 col-xs-2 col-form-label">Email</label>
							<div class="col-xs-7">
								<input class="form-control" name="email" type="text" value="{{$user->email}}" id="email">
							</div>
						</div>

						<div class="form-group row">
							<label for="website" class="col-xs-offset-1 col-xs-2 col-form-label">Website</label>
							<div class="col-xs-7">
								<input class="form-control" name="website" type="url" value="{{$uprof->website}}" id="website">
							</div>
						</div>

						<div class="form-group row">
							<label for="gitlink" class="col-xs-offset-1 col-xs-2 col-form-label">Git-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="gitlink" type="url" value="{{$uprof->gitlink}}" id="gitlink">
							</div>
						</div>
  
						<div class="form-group row">
							<label for="fblink" class="col-xs-offset-1 col-xs-2 col-form-label">Facebook-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="fblink" type="url" value="{{$uprof->fblink}}" id="fblink">
							</div>
						</div>

						<div class="form-group row">
							<label for="twitlink" class="col-xs-offset-1 col-xs-2 col-form-label">Twitter-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="twitlink" type="url" value="{{$uprof->twitlink}}" id="twitlink">
							</div>
						</div>

						<div class="form-group row">
							<label for="lilink" class="col-xs-offset-1 col-xs-2 col-form-label">LinkedIn-link</label>
							<div class="col-xs-7">
								<input class="form-control" name="lilink" type="url" value="{{$uprof->lilink}}" id="lilink">
							</div>
						</div>

						<div class="form-group row">
							<label for="langs" class="col-xs-offset-1 col-xs-2 col-form-label">Language</label>
							<div class="col-xs-7">
								<input class="form-control" name="langs" type="text" value="{{$uprof->languages}}" id="langs">
							</div>
						</div>


						<div class="form-group row">
							<label for="about" class="col-xs-offset-1 col-xs-2 col-form-label">About</label>
							<div class="col-xs-7">
								<textarea required class="form-control" name="about" rows="5" type="text" id="about">{{$uprof->about}}</textarea>
							</div>
						</div>

						<div class="form-group row">
							<label for="interests" class="col-xs-offset-1 col-xs-2 col-form-label">Interests</label>
							<div class="col-xs-7">
								<textarea required class="form-control" name="interests" rows="5" type="text" id="interests">{{$uprof->interests}}</textarea>
							</div>
						</div>

						<div class="form-group row">
							<label for="keywords" class="col-xs-offset-1 col-xs-2 col-form-label">Keywords</label>
							<div class="col-xs-7">
								<textarea required class="form-control" name="keywords" rows="5" type="text" id="keywords">{{$uprof->keywords}}</textarea>
							</div>
						</div>

						<div class="form-group row">
								<button type="submit" class="col-xs-offset-8 btn btn-primary">Save</button> 
								<button type="button" class="btn btn-primary" onclick="window.location.href='../{{$uprof->username}}'">Cancel</button>
						</div>


					</form>

				</div>
			</div>
		</div>
	</div>
</div>

@stop

@section('scripts')
<script type="text/javascript">
	
/*	$.get('http://maps.googleapis.com/maps/api/geocode/json?address=House+A+47,+Shadman+Town+2,+North+Karachi,+Pakistan&sensor=false', function(){ 
        success: function( data ) {
                console.log(data);
            }
        //console.log('response'); 
    });
*/
	var lat;
	var lon;
/*
	$.ajax({
				type: "GET",
				url: "http://maps.googleapis.com/maps/api/geocode/json?address=House+A+47,+Shadman+Town+2,+North+Karachi,+Pakistan&sensor=false",
				success: function(result){
					lat = result.results[0].geometry.location.lat;
					lon = result.results[0].geometry.location.lng;
					console.log(lat + " " + lon);
					$.ajax({
						type: "GET",
						url: "http://maps.googleapis.com/maps/api/geocode/json?address=Room+105,+Attar+1+Hostels,+Nust+H+12,+Islamabad,+Pakistan&sensor=false",
						success: function(result){
							lat = result.results[0].geometry.location.lat;
							lon = result.results[0].geometry.location.lng;
							console.log(lat + " " + lon);
				        }
					});	
		        }
			});		
*/
	$("#fep").submit(function( event ) {
		event.preventDefault();
		var addr = $("#address").val() + ", " + $("#city").val() + ", " + $("#country").val(); // Google HQ
        var spc = " ";
        var prepAddr = addr.replace(/ /g, '+');
        prepAddr = prepAddr.replace(/-/g, ''); 
        alert(prepAddr);
		$.ajax({
				type: "GET",
				url: "http://maps.googleapis.com/maps/api/geocode/json?address="+prepAddr+"&sensor=false",
				success: function(result){
					lat = result.results[0].geometry.location.lat;
					lon = result.results[0].geometry.location.lng;
				//	alert(lat + " " + lon);
					$.ajax({
						type: "POST",
						url: "/{{$uprof->username}}",
						data: {proftitle: $("#proftitle").val(), address: $("#address").val(), city: $("#city").val(), country: $("#country").val(), postcode: $("#postcode").val(),lat: lat,lon: lon, email: $("#email").val(), website: $("#website").val(), gitlink: $("#gitlink").val(), fblink: $("#fblink").val(), twitlink: $("#twitlink").val(), lilink: $("#lilink").val(), langs: $("#langs").val(), about: $("#about").val(), interests: $("#interests").val(), keywords: $("#keywords").val(),  _token: "{{ Session::token() }}"},
						success: function(){
							window.location="/{{$uprof->username}}";
				        }
					});
		        }
		});		
		
		
	});

</script>
@endsection