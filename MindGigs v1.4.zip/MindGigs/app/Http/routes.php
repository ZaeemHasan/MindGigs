<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
/*
Route::bind('profile',function($uname){
	return App/Profile::where('username',$uname)->first();
})
*/


Route::get('/home', function () {
		if (Auth::check()) {
			return view('home');
		} else {
			return Redirect::to('login');
		}
	});


//Route::get('/p','ProfilesController@index');
//Route::post('/p', 'ProfilesController@create');		// for posting data of edited profile

// made indirect links by making showep.blade.php and show.blade.php to make it more secure

Route::get('/', function () {
    if (Auth::check()) {
			return Redirect::to('home');
		} else {
			return view('welcome');
		}
});



Route::get('/profile', function () {
		if (Auth::check()) {
			return view('profile');
		} else {
			return Redirect::to('login');
		}
	});

/* Note that: localhost:8000/editprofile and localhost:8000/profile are not to be official pages acc to me, 
coz they arent generic, that's why i've made /p/{$id} -- for profile ; and /p/{$id}/editprofile 

*/

/*
Route::get('/editprofile', function () {
		if (Auth::check()) {
			return view('editprofile');
		} else {
			return Redirect::to('login');
		}
	});
*/
Route::auth();

Route::get('{id}','ProfilesController@show');			// for profile page .--------- make profile page here
Route::get('{id}/editprofile','ProfilesController@showep');		// for editing profile page ------ make edit profile here

Route::post('{id}', 'ProfilesController@create');		// for posting data of edited profile

