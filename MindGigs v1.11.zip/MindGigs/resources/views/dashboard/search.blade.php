@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row">
	<br><br>
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading">Search Jobs</div>

				<div class="panel-body">
						

						<div class="form-group row">

							<textarea required class="col-xs-offset-1 col-xs-10" placeholder="Enter keywords for searching relevat jobs" name="searchbar" type="text" id="searchbar"></textarea>
							<center>
								<button type="button" class="btn btn-primary" onclick="searchbtn()">Search</button> 			
								<!-- this button will be connected to ajax post request to route '/searchjobs'-->
							</center>
							
						</div>
						<br>
						 <center>OR</center>
						 <br><br>
						
						<div class="form-group row">
							<center>
								<button type="button" class="btn btn-primary" onclick="">Search According To Your Registered Interests</button>  		
								<!-- this button will be connected to ajax get request to route '/searchjobsint'-->
							</center>
						</div>
	
							<!-- Note that both of their controller methods are ready, and working perfectly so the only problem to get the data from there and post it here, as I was not able to do that
								So Ammar please you do that. -->


				</div>
			</div>
		</div>
	</div>
</div>

@stop


@section('scripts')
<script type="text/javascript">

	function searchbtn(){
		alert("inside search");

		
		$.ajax({
			type: "POST",
			url: "/searchjobs",
			data: {tosearch: $("#searchbar").val(), _token: "{{ Session::token() }}"},
			success: function(result){
				alert(result.posts);
	        }
		});

/*		$.get('/searchjobs/php',function(data){
    		alert("after ajax");
    	});	
*/    	
	}

	function searchAcInt(){		// search according to interests
				
	}

</script>
@endsection
